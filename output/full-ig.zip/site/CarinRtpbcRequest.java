package http://hl7.org/fhir/us/carin/ImplementationGuide/carin-rtpbc;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class CarinRtpbcRequest {

}
